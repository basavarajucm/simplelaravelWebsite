<?php $__env->startSection('content'); ?>
<h1> contact</h1>
<?php echo Form::open(['url' => 'contact/submit']); ?>

<div class="form-group">
	<?php echo e(Form::label('name', 'name')); ?>

	<?php echo e(Form::text('name', '', ['class'=>'form-control', 'placeholder'=>'Enter Name'])); ?>

</div>

<div class="form-group">
	<?php echo e(Form::label('email', 'email')); ?>

	<?php echo e(Form::text('email', '', ['class'=>'form-control', 'placeholder'=>'Enter Email'])); ?>

</div>

<div class="form-group">
	<?php echo e(Form::label('message', 'message')); ?>

	<?php echo e(Form::textarea('message', '', ['class'=>'form-control', 'placeholder'=>'Enter Message'])); ?>

</div>

<?php echo e(Form::submit('Send', ['class'=>'btn btn-primary'])); ?>


<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>