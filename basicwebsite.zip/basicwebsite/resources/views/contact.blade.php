@extends('layouts.app')

@section('content')
<h1> contact</h1>
{!! Form::open(['url' => 'contact/submit']) !!}
<div class="form-group">
	{{Form::label('name', 'name')}}
	{{Form::text('name', '', ['class'=>'form-control', 'placeholder'=>'Enter Name'])}}
</div>

<div class="form-group">
	{{Form::label('email', 'email')}}
	{{Form::text('email', '', ['class'=>'form-control', 'placeholder'=>'Enter Email'])}}
</div>

<div class="form-group">
	{{Form::label('message', 'message')}}
	{{Form::textarea('message', '', ['class'=>'form-control', 'placeholder'=>'Enter Message'])}}
</div>

{{Form::submit('Send', ['class'=>'btn btn-primary'])}}

{!! Form::close() !!}
@endsection