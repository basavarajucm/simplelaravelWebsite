<div class="jumbotron text-center">
	<div class="container">
		<p>WELCOME TO NEW LARAVEL WEBSITE</p>
	</div>
</div>