@section('sidebar')
  	<div class="well">
  		<h1>This is side bar</h1>
  		  @show
  	</div>