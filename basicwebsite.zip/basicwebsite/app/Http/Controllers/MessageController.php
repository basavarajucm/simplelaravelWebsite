<?php

namespace App\Http\Controllers;
use App\Message;
use Illuminate\Http\Request;

class MessageController extends Controller
{
    public function submit(Request $request)
    {
    	$this->validate($request,[
    		'name'=>'required',
    		'email'=>'required'
    	]);
    	$name=  $request->input('name');
    	$email = $request->input('email');
    	$message = $request->input('message');

    	$message=new Message;

    	$message->name=$name;
    	$message->email = $email;
    	$message->message= $message;

    	//$message->save();

    	return redirect('/contact')->with('message','Message sent');
    }

    public function getMessages()
    {
    	$messages=Message::all();
    }
}
